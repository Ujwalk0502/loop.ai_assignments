package Pages;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class Table_data extends Driver {

	
	
	public void data() {
       
		ArrayList<String> headerValues = new ArrayList<>();
        ArrayList<String> rowData = new ArrayList<>();
      

        // Find the table header element and extract header values
        WebElement headerRow = driver.findElement(By.xpath("//thead[@class='MuiTableHead-root css-15wwp11-MuiTableHead-root']"));
        String[] headers = headerRow.getText().split("\n");
        for (String header : headers) {
            headerValues.add(header);
            System.out.println(headerValues);
        }

      
        //WebElement table = driver.findElement(By.xpath("//table[@class='MuiTable-root css-15i8i05-MuiTable-root']"));

      
        for (int i = 1; i <= 25; i++) {
        	for(int j=1; j<=3; j++){
            WebElement row = driver.findElement(By.xpath("//tbody//tr[" + j + "]"));
            
            String rowDataText = row.getText();
            //System.out.println(rowDataText);
            rowData.add(rowDataText);

           
        }

       
        String csvFile = "table_data.csv";

        try (FileWriter fileWriter = new FileWriter(csvFile)) {
            // Write header values to the CSV file
            for (String header : headerValues) {
                fileWriter.append(header).append(",");
            }
            fileWriter.append("\n");

            // Write row data to the CSV file
            for (String data : rowData) {
                fileWriter.append(data).append(",");
            }
            fileWriter.append("\n");
            //System.out.println("CSV file has been created successfully!");

        } catch (IOException e) {
            e.printStackTrace();
            
        }}
    driver.quit();    
	}
	
}
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
/*		// Find the table header element and extract header values
        WebElement headerRow = driver.findElement(By.xpath("//thead[@class='MuiTableHead-root css-15wwp11-MuiTableHead-root']"));
        String[] headers = headerRow.getText().split("\n");
        for (String header : headers) {
            headerValues.add(header);
            System.out.println(headerValues);
        }
		
        for (int i = 1; i <= 25; i++) {
		
        	//for(int j=1; j<=3; j++){
                WebElement row = driver.findElement(By.xpath("//tbody/tr["+i+"][1]"));
                String[] rows=row.getText().split("\n");
                for(String rowvalue:rows ){
                	rowData.add(rowvalue);
                	
                	
                
            }System.out.println(rowData);
                rowData.clear();
                
                }
	
        
   
        	for(int k=1; k<=30; k++){
			for (int n=k; n<=k; n++){
				String text = driver.findElement(By.xpath("//tbody//td["+n+"]")).getText();
				System.out.println(text);
			}
		
		*/
        
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		/*ArrayList<String> headerValues = new ArrayList<>();
        ArrayList<String> rowData = new ArrayList<>();

        // Find the table header element and extract header values
        WebElement headerRow = driver.findElement(By.xpath("//thead[@class='MuiTableHead-root css-15wwp11-MuiTableHead-root']"));
        String[] headers = headerRow.getText().split("\n");
        for (String header : headers) {
            headerValues.add(header);
            System.out.println(headerValues);
        }

        // Find the table data element
        WebElement table = driver.findElement(By.xpath("//table[@class='MuiTable-root css-15i8i05-MuiTable-root']"));

        // Find the table rows and extract row data
        for (int i = 1; i <= 25; i++) {
        	for(int j=1; j<=3; j++){
            WebElement row = driver.findElement(By.xpath("//tbody//tr[" + j + "]"));
            
            String rowDataText = row.getText();
            System.out.println(rowDataText);
            rowData.add(rowDataText);

            // Add a newline character to separate rows in CSV file
            //rowData.add("\n");
        }
System.out.println("entering next loop");
        // Define the CSV file name
        String csvFile = "table_data.csv";

        try (FileWriter fileWriter = new FileWriter(csvFile)) {
            // Write header values to the CSV file
            for (String header : headerValues) {
                fileWriter.append(header).append(",");
            }
            fileWriter.append("\n");

            // Write row data to the CSV file
            for (String data : rowData) {
                fileWriter.append(data).append(",");
            }
            fileWriter.append("\n");
            System.out.println("CSV file has been created successfully!");

        } catch (IOException e) {
            e.printStackTrace();*/
	
	
	
	
	
	
	
	
	/*public void data(){
		ArrayList<String> Values=new ArrayList<String>();
		
	      WebElement tableData = driver.findElement(By.xpath("//table[@class='MuiTable-root css-15i8i05-MuiTable-root']"));
	      
	      String headervalues = driver.findElement(By.xpath("//thead[@class='MuiTableHead-root css-15wwp11-MuiTableHead-root']")).getText();
	      System.out.println(headervalues);
	      
	      //store the variable header values in csv file header
	      
	      for(int i=1; i<=25; i++){
	    	  
	    	  for(int j=1; j<=3; j++){
	    	  String datas = driver.findElement(By.xpath("//tbody//tr["+i+"]")).getText();
	    	  System.out.println(datas);
	      
	       }
	    //iterate to the next row in csv file here
	    	  //System.out.println("entering next loop");
	      }
	      
	      */
	      
	      
	      
	      
	      
	      
	      
	     /* 
	        String[] rows = tableData.split("\\n");

	        // Define the CSV file name
	        String csvFile = "table_data.csv";

	        try (FileWriter fileWriter = new FileWriter(csvFile)) {
	            // Write data to the CSV file
	            for (String row : rows) {
	                // Split each row by tab character
	                String[] columns = row.split("\t"); // Assuming the columns are separated by tabs

	                // Write each column to the CSV file
	                for (int i = 0; i < columns.length; i++) {
	                    fileWriter.append(columns[i]);
	                    if (i != columns.length - 1) {
	                        fileWriter.append(",");
	                    }
	                }
	                fileWriter.append("\n");
	            }

	            System.out.println("CSV file has been created successfully!");

	        } catch (IOException e) {
	            e.printStackTrace();
	        }*/
	    




