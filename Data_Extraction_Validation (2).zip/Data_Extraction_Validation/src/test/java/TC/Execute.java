package TC;

import java.util.concurrent.TimeUnit;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import Pages.Driver;

import Pages.Login_page;
import Pages.Table_data;
import Pages.Transactions;



public class Execute extends Driver{

	@Parameters({"Uname","pwd"})
	@Test
	public void Execute(String Uname, String pwd) throws Exception{
	driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	
	//Login to application
	LG =new Login_page(driver);
	LG.getSign_inwithout_password().click();
	Thread.sleep(5000);
	LG.getUserName().sendKeys(Uname);
	LG.getPassword().sendKeys(pwd);
	LG.getLoginbtn().click();
	Thread.sleep(10000);
	LG.getSkip().click();
	
    //Navigating to Transaction page
	TS =new Transactions(driver);
	driver.get("https://app.tryloop.ai/chargebacks/transactions");
	Thread.sleep(5000);
	TS.choose();
	
	
	//fetching table data
	TD=new Table_data();
			TD.data();
	
	}
	
	}

	
	

