package Utilities;

public class Object_class {

}
