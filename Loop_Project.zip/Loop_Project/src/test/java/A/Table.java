package A;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class Table extends Driver {

	
	public void Total(){
	
		WebElement Display = driver.findElement(By.xpath("(//h6[@class='MuiTypography-root MuiTypography-subtitle2 css-m09714-MuiTypography-root'])[1]"));
		WebElement Name = null;
		if(Display.isDisplayed()){
		for (int i=2; i<9; i++){
			WebElement Months = driver.findElement(By.xpath("(//h6[@class='MuiTypography-root MuiTypography-subtitle2 css-m09714-MuiTypography-root'])["+i+"]"));
		    String Monthname=Months.getText();
			System.out.println(Monthname);
						for (int j=1; j<=5; j++){
		
	          Name = driver.findElement(By.xpath("(//tr[@class='MuiTableRow-root css-1un8s7z-MuiTableRow-root'])["+j+"]"));
	          String names=Name.getText();
					for(int k=2;k<=10;k++){
					System.out.println(names);
					}
					
					
				
				
}
	//
			   
				  /* for(int n=2;n<10;n++){
					   driver.findElement(By.xpath(""))
				   }
			*/
			   
	
	
			}

						
}
}}
//(//tr[@class='MuiTableRow-root css-1un8s7z-MuiTableRow-root'])[]