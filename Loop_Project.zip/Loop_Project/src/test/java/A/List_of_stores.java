package A;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class List_of_stores {

	@FindBy(xpath="//div[@role='combobox']")
	WebElement dropdown;
	
	@FindBy(xpath="//p[.='Reversals']")
	WebElement reversal_value;
	
	public List_of_stores(WebDriver driver){
		PageFactory.initElements(driver, this);
	}
		
		
		public void visible(){
	if(reversal_value.isDisplayed()){
		System.out.println("Dropdown value is choosed as Reversals");
	}		
	else{
		Select s1=new Select(dropdown);
		s1.selectByVisibleText("Reversals");
	}
	}
	
	
}
