package A;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class Login_page extends Driver{

	@FindBy(xpath="//a[@href='/login/password']")
	WebElement Sign_inwithout_password;
	
	@FindBy(xpath="//input[@type='text']")
	WebElement userName;
	
	@FindBy(xpath="//input[@type='password']")
	WebElement Password;
	
	@FindBy(xpath="//button[@data-testid='login-button']")
	WebElement loginbtn;
	
	@FindBy(xpath="//button[.='Skip for now']")
	WebElement skip;
	
	
	public Login_page(WebDriver driver){
	PageFactory.initElements(driver, this);
	}
	

	public WebElement getSign_inwithout_password() {
		return Sign_inwithout_password;
	}
	
	public WebElement getUserName() {
		return userName;
	}

	public WebElement getPassword() {
		return Password;
	}
	
	public WebElement getLoginbtn() {
		return loginbtn;
		
		
	}

	public WebElement getSkip() {
		return skip;
	}

}
