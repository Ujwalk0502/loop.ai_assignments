package TC;

import java.util.concurrent.TimeUnit;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import A.Driver;
import A.List_of_stores;
import A.Login_page;
import A.Table;


public class tc extends Driver{

	@Parameters({"Uname","pwd"})
	@Test
	public void Execute(String Uname, String pwd) throws Exception{
	driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	
	//Login to application
	LG =new Login_page(driver);
	LG.getSign_inwithout_password().click();
	Thread.sleep(5000);
	LG.getUserName().sendKeys(Uname);
	LG.getPassword().sendKeys(pwd);
	LG.getLoginbtn().click();
	Thread.sleep(10000);
	LG.getSkip().click();;
	
	//Selecting the dropdown value as Reversal
	LS=new List_of_stores(driver);
	driver.get("https://app.tryloop.ai/chargebacks/stores/view");
	LS.visible();
	Thread.sleep(20000);
	
	//selecting months in table
	tbl=new Table();
	tbl.Total();
	
	
	
	
	
	}
	
	}

	
	

