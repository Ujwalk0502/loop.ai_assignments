package Pages;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class Table_data extends Driver {

	
	
	public void data() {
       
		ArrayList<String> headerValues = new ArrayList<>();
        ArrayList<String> rowData = new ArrayList<>();
      

        // Find the table header element and extract header values
        WebElement headerRow = driver.findElement(By.xpath("//thead[@class='MuiTableHead-root css-15wwp11-MuiTableHead-root']"));
        String[] headers = headerRow.getText().split("\n");
        for (String header : headers) {
            headerValues.add(header);
            System.out.println(headerValues);
        }

      
        //WebElement table = driver.findElement(By.xpath("//table[@class='MuiTable-root css-15i8i05-MuiTable-root']"));

      
        for (int i = 1; i <= 25; i++) {
        	for(int j=1; j<=3; j++){
            WebElement row = driver.findElement(By.xpath("//tbody//tr[" + j + "]"));
            
            String rowDataText = row.getText();
            //System.out.println(rowDataText);
            rowData.add(rowDataText);

           
        }

       
        String csvFile = "table_data.csv";

        try (FileWriter fileWriter = new FileWriter(csvFile)) {
            // Write header values to the CSV file
            for (String header : headerValues) {
                fileWriter.append(header).append(",");
            }
            fileWriter.append("\n");

            // Write row data to the CSV file
            for (String data : rowData) {
                fileWriter.append(data).append(",");
            }
            fileWriter.append("\n");
            //System.out.println("CSV file has been created successfully!");

        } catch (IOException e) {
            e.printStackTrace();
            
        }}
    driver.quit();    
	}
	
}
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        




