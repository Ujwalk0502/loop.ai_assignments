package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class Transactions {

	@FindBy(xpath="(//button[@type='button'])[8]")
	WebElement Location_dropdown;
	
	@FindBy(xpath="//p[.='Unselect All (109)']")
	WebElement unselect_checkbox;
	
	@FindBy(xpath="//p[.='Artisan Alchemy']")
	WebElement Artisan_Alchemy;
	
	@FindBy(xpath="//p[.='Blissful Buffet']")
	WebElement Blissful_Buffet;
	
	@FindBy(xpath="//button[@data-testid='applyBtn']")
	WebElement ApplyBtn;
	
	@FindBy(xpath="(//button[@type='button'])[10]")
	WebElement Marketplace_dropdown;
	
	@FindBy(xpath="//p[.='Unselect All (3)']")
	WebElement UnselectAll_checkbox;
	
	@FindBy(xpath="//p[.='Grubhub']")
	WebElement Grub_hub;
	
	@FindBy(xpath="//h6[.='REVERSAL']")
	WebElement display;
	
	public  Transactions(WebDriver driver){
		PageFactory.initElements(driver, this);
	}
	
	public void choose() throws Exception{
		Location_dropdown.click();
		Thread.sleep(2000);
		
		unselect_checkbox.click();
		Thread.sleep(2000);
		
		Artisan_Alchemy.click();
		
		Blissful_Buffet.click();
		
		ApplyBtn.click();
		Thread.sleep(2000);
		
		Marketplace_dropdown.click();
		Thread.sleep(2000);
		
		UnselectAll_checkbox.click();
		Thread.sleep(2000);
		
		Grub_hub.click();
		
		ApplyBtn.click();
		Thread.sleep(2000);
		
		if(display.isDisplayed()){
			System.out.println("Table data is loaded");
		}
		else{
			System.out.println("Table data isn't loaded");
		}
	}
	
}
