package Pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Driver {

	
	public static WebDriver driver;
	public static Login_page LG;
	public static Transactions TS;
	public static Table_data TD;

	
	@Parameters({"Browser","URL","Uname","pwd"})
	@BeforeTest
	public void setup(String Browser, String URL, String Uname, String pwd) throws Exception{
		
		if (Browser.equalsIgnoreCase("chrome")){

			 System.setProperty("webdriver.chrome.driver","C:\\Users\\ukumar\\Selenium_workspace_2\\UJ_workspace\\chromedriver-win32\\chromedriver.exe");
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--remote-allow-origins=*");
			WebDriver driver = new ChromeDriver(options);
			 driver=new ChromeDriver();
		
	}
		else if(Browser.equalsIgnoreCase("firefox")){
			WebDriverManager.firefoxdriver().driverVersion("0.33.0").setup();
			driver=new FirefoxDriver();
		}
		
		driver.get(URL);
		driver.manage().window().maximize();
		
		
		
}
	
}